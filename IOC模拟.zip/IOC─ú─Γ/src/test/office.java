package test;

public class office {
   private String officeId;

	public String getOfficeId() {
		return officeId;
	}
	
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	public String tostring(){
		return "office" +officeId;
	}

}
